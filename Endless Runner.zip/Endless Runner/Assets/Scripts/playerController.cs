﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class playerController : MonoBehaviour
{
    // Start is called before the first frame update
    private CharacterController control;
    public Vector3 direction;
    public float speed=10;
    private int lane = 1;
    public float laneDistance = 5;
    public float jumpfrc = 10;
    public float gravity = 5;
    void Start()
    {
        control = GetComponent<CharacterController>();


    }

    // Update is called once per frame

    private void Update()
    {
        direction.z = speed;
        
        if (control.isGrounded)
        {
            direction.y = 0;
            if (Input.GetKeyDown(KeyCode.Space))
            {
                JumpKarao();
            }
        }
        else
        {
            direction.y += gravity * Time.deltaTime;
        }
        if (Input.GetKeyDown(KeyCode.RightArrow))
        {
            lane++;
            if (lane == 3)
            {
                lane = 2;
            }
        }

        if (Input.GetKeyDown(KeyCode.LeftArrow))
        {
            lane--;
            if (lane == -1)
            {
                lane = 0;
            }
        }


        Vector3 target = transform.position.z * transform.forward + transform.position.y * transform.up;

        if (lane == 0)
        {
            target += Vector3.left * laneDistance;
        }
        else if (lane == 2)
        {
            target += Vector3.right * laneDistance;
        }

        transform.position = Vector3.Lerp(transform.position, target, 80 * Time.deltaTime);
        control.center = control.center;
    }
    void FixedUpdate()
    {
        control.Move(direction * Time.deltaTime);
    }

    private void JumpKarao()
    {
        direction.y = jumpfrc;
    }

    private void OnControllerColliderHit(ControllerColliderHit hit)
    {
        if (hit.transform.tag == "Obstacle")
        {
            Debug.Log("We hit something");
            Trigger.gg = true;

        }
    }
}
